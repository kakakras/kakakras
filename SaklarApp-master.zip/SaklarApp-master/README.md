# SaklarApp
Aplikasi monitoring dan kontrol peralatan listrik seperti lampu rumah menggunakan NodeMCU dan dilengkapi dengan antarmuka web moderen yang dapat diakses dari Smart Phone Android.

# Cara Setup
Tutorial lengkap ada di link berikut: https://tutorkeren.com/artikel/tutorial-menyalakan-lampu-rumah-web-dan-wifi-android.htm
