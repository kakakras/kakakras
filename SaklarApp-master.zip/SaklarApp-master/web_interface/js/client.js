jQuery(document).ready(function($) {
	"use strict"; // Start of use strict
  
}); // End of use strict